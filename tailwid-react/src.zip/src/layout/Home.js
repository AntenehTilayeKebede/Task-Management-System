import React, { useState } from 'react';
import Navb from '../component//Navb';
import Main from '../component/Main'
import Footer from '../component/Footer';


const HomePage = () => {
  const [nav, setNav] = useState(false);

  const handleNav = () => {
    setNav(!nav);
  };

  return (
    <div>
     
      <Navb nav={nav} handleNav={handleNav} />

      
      <Main />

      
      <Footer />
    </div>
  );
};

export default HomePage;
