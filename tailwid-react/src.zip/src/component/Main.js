
const Main = () => {
  return (
    <div className="relative">
  <div className=' md:flex   md:justify-between items-center  md:gap-5 md:m-15  md:m-20  '>
    <div className=' h-48 md:h-64 w-[50%] m-20 ' >
    <img
        src="images/intern.jpeg"
        alt="Logo"
        className="w-full  h-64 md:h-64  mx-auto object-contain md:object-cover  "
      />

    </div>
    <div className=' w-full  border overflow-hidden p-[6%] '>
    It's important to choose the right software solution based on the organization's requirements, scalability, security, and budget considerations. Additionally, many companies provide software consulting services to help businesses identify the most suitable solutions and guide them through the implementation process.

    </div>
    </div>

    <div className='hidden lg:text-black lg:grid  lg:justify-center lg:items-center lg:font-serif lg:text-lg  lg:absolute  lg:left-[70%]  lg:top-[-10px] '>
      <div>SOFTWARE </div> 
      <span className=' text-red-500 first-letter:text-black'>SOLUTIONS</span> 
    </div>     
             
  </div>
  )
}

export default Main