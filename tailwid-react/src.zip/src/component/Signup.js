import React from "react";

function Signup() {
  return (
    <div className="bg-blue-200 min-h-screen flex justify-center items-center">
      <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full">
        <h2 className="text-center text-2xl text-red-600 mb-6 font-bold">
          <u>Sign Up</u>
        </h2>

        <form className="space-y-4">
          <div>
            <label htmlFor="Full_Name" className="block font-semibold text-gray-600">
              Full Name
              <span className="text-red-600">*</span>
            </label>
            <input
              type="text"
              placeholder="Enter Your Full Name"
              name="Full_Name"
              id="Full_Name"
              className="w-full h-10 px-3 border rounded focus:outline-none focus:ring focus:ring-red-600"
              required
            />
          </div>
          
          <div>
            <label htmlFor="Username" className="block font-semibold text-gray-600">
              Username
            </label>
            <input
              type="text"
              placeholder="E.g: @Ante210"
              name="Username"
              id="Username"
              className="w-full h-10 px-3 border rounded focus:outline-none focus:ring focus:ring-red-600"
            />
          </div>

          <div>
            <label htmlFor="Email" className="block font-semibold text-gray-600">
              Email
              <span className="text-red-600">*</span>
            </label>
            <input
              type="email"
              placeholder="E.g: ************@gmail.com"
              name="Email"
              id="Email"
              className="w-full h-10 px-3 border rounded focus:outline-none focus:ring focus:ring-red-600"
              required
            />
          </div>

          <div>
            <label htmlFor="Password" className="block font-semibold text-gray-600">
              Password
              <span className="text-red-600">*</span>
            </label>
            <input
              type="password"
              placeholder="Enter Password"
              name="Password"
              id="Password"
              className="w-full h-10 px-3 border rounded focus:outline-none focus:ring focus:ring-red-600"
              required
            />
          </div>

          <div>
            <button
              type="submit"
              className="bg-red-600 text-white w-full h-10 rounded-md hover:bg-red-700 transition duration-300"
            >
              Sign Up
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Signup;
