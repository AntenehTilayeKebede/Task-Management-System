import React from "react";
import { Link } from "react-router-dom";

function Login() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="max-w-md w-full p-8 bg-white rounded-lg shadow-lg">
        <h1 className="text-blue-600 text-4xl font-bold mb-8 text-center">
          Login
        </h1>
        <form className="space-y-6">
          <input
            type="email"
            placeholder="Email"
            required
            className="w-full h-12 px-4 border border-gray-300 rounded focus:ring focus:ring-blue-200"
          />
          <input
            type="password"
            placeholder="Password"
            required
            className="w-full h-12 px-4 border border-gray-300 rounded focus:ring focus:ring-blue-200"
          />
          <div className="flex justify-center">
            <button className="w-full h-12 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-300">
              Login
            </button>
          </div>
        </form>
        <div className="mt-4 text-center">
          <hr className="border-t border-gray-300" />
          <p className="mt-4">
            Don't have an account?{" "}
            <Link to="signup" className="text-blue-600 font-semibold">
              Sign Up
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Login;