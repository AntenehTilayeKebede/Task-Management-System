import { NavLink } from "react-router-dom"
const Me = () => {
  return (
    <div> <p className="p-4 "> page did not found</p> 
      <NavLink className='p-4 text-red-800'  to='/'> goback to Home</NavLink> 
    </div>
    
  )
}

export default Me