import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
const BASE_URL = 'http://localhost:8000'; // Update with your server URL

const Forma = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ title: '', description: '' });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      await axios.post(`${BASE_URL}/issueinfo`, formData); // Send the form 
      navigate('/task');

      
      setFormData({ title: '', description: '' });
    } catch (error) {
      console.error('Error adding data:', error);
    }
  };

  return (
    <div className="bg-[#eef4fb] min-h-screen flex flex-col justify-center items-center">
      <div className="bg-[#f6f6f6] p-8 rounded-lg shadow-md mt-8 w-full max-w-[700px] sm:w-[80%] sm:max-w-[600px]">
        <h2 className="text-center text-4xl text-[#007ae6] mb-6 font-extrabold">
          Add Issue
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="mb-4">
            <label className="block font-bold text-gray-600 text-lg">
              Title
              <span className="text-red-600">*</span>
            </label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              placeholder="Enter title of the issue"
              className="w-full h-12 px-4 border rounded focus:outline-none focus:ring focus:ring-blue-500"
              required
            />
          </div>

          <div className="mb-6">
            <label className="block font-bold text-gray-600 text-lg">
              Description
              <span className="text-red-600">*</span>
            </label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              placeholder="Enter description of the issue"
              className="w-full h-32 px-4 py-2 border rounded focus:outline-none focus:ring focus:ring-blue-500"
            ></textarea>
          </div>

          <button
            type="submit"
            className="bg-[#007ae6] text-white w-[150px] h-[50px] rounded-md transition duration-300 font-bold hover:bg-blue-600"
          >
            Add Issue
          </button>
        </form>
      </div>
    </div>
  );
};

export default Forma;
