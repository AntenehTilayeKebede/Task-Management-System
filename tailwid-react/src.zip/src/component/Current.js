import React, { useEffect, useState } from 'react';
import axios from 'axios';

const BASE_URL = 'http://localhost:8000'; // Make sure your server is running on port 8000

const Current = () => {
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deletingIssueId, setDeletingIssueId] = useState(null);

  useEffect(() => {
    const fetchIssues = async () => {
      try {
        const response = await axios.get(`${BASE_URL}/issueinfo`);
        setIssues(response.data); // Assuming the response data contains an array of issues
        setLoading(false);
      } catch (error) {
        console.error('Error fetching issues:', error);
        setLoading(false);
      }
    };

    fetchIssues();
  }, []);

  const handleDeleteIssue = async (issueId) => {
    try {
      // Send a DELETE request to the server to delete the issue
      await axios.delete(`${BASE_URL}/issueinfo/${issueId}`);

      // Remove the deleted issue from the local state
      setIssues((prevIssues) => prevIssues.filter((issue) => issue.id !== issueId));
    } catch (error) {
      console.error('Error deleting issue:', error);
    } finally {
      setDeletingIssueId(null); // Reset deletingIssueId
    }
  };

  const confirmDelete = (issueId) => {
    if (window.confirm('Are you sure you want to delete this issue?')) {
      setDeletingIssueId(issueId);
      handleDeleteIssue(issueId);
    }
  };

  return (
    <div className="bg-gray-100 min-h-screen">
      <div className="container mx-auto py-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-6">Current Issues</h1>
        {loading ? (
          <p className="text-gray-600">Loading...</p>
        ) : (
          <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {issues.map((issue) => (
              <li key={issue.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-4">
                  <h2 className="text-xl font-semibold text-gray-800">{issue.title}</h2>
                  <p className="text-gray-600 mt-2">{issue.description}</p>
                  <button
                    onClick={() => confirmDelete(issue.id)}
                    className="mt-4 bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600"
                    disabled={deletingIssueId === issue.id}
                  >
                    {deletingIssueId === issue.id ? 'Deleting...' : 'Delete'}
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default Current;
