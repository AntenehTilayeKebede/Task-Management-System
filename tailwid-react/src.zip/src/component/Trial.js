<div className='bg-[url("https://media.istockphoto.com/id/1509369742/photo/typing-keyboard-to-management-organization-human-resource-social-and-network-to-make.jpg?s=612x612&w=0&k=20&c=xeThRBAKzXvIQcYFDgNJCUhwQlQ_UfPc5P5NW8KtUho=")] w-full bg-cover'>
    <div className='  cctext-white bg-cover bg-no-repeat  bg-w-auto h-[500px] mx-auto justify-betweenbg-fixed md:shrink-0 md:items-center '>
      <h1 className='w-full text-3xl font-bold text-[#698f83]'>LOGO</h1>
      <ul className='hidden md:flex'>
        <li className='p-4'>HOME</li>
        <li className='p-4' >CURRENT_ISSUE</li>
        <li className='p-4'>ABOUT</li>
        <li className='p-4'>CONTACT</li>
        <li className='p-4'>ADD_ISSUE</li>
      </ul>
      <div className='grid-rows-2 items-end  gap-4'>
        <button className='object-contain flex m-4 p-2 rounded-md bg-red-100 items-center text-red-600'>SIGN_UP</button>
        <button className='mr-28 flex  text-red-600 m-4 p-2 rounded-md bg-red-100 items-center'>SIGN_UP</button>

        
      </div>
      <div onClick={handleNav} className='block md:hidden'>
          {nav ? <AiOutlineClose size={20}/> : <AiOutlineMenu size={20} />}
      </div>
      <ul className={nav ? 'fixed left-0 top-0 w-[60%] h-full border-r border-r-gray-900 bg-[#000300] ease-in-out duration-500' : 'ease-in-out duration-500 fixed left-[-100%]'}>
        <h1 className='w-full text-3xl font-bold text-[#00df9a] m-4'>LOGO</h1>
        
          <li className='p-4 border-b border-gray-600'>HOME</li>
          <li className='p-4 border-b border-gray-600'>CURRENT_ISSUE</li>
          <li className='p-4 border-b border-gray-600'>ABOUT</li>
          <li className='p-4 border-b border-gray-600'>CONTACT</li>
          <li className='p-4'>ADD</li>
          
      </ul>
      
      
    </div>
    </div>