import React, { useState } from 'react'
import { NavLink,Outlet } from 'react-router-dom';

import { AiOutlineClose, AiOutlineMenu } from 'react-icons/ai'

  


const Navbar = () => {
  const [nav, setNav] = useState(false);

  const handleNav = () => {
    setNav(!nav);
  };

  return (
    <div className="bg-custom-background md:h-96  lg:h-[500px] bg-cover ">
      <div className='grid grid-cols-4 gap-8'>
                <div className='  h-full  rows-span-2 '>
                <img
        src="images/white.png"
        alt="Logo"
        className="w-24 object-contain  h-24 mx-auto my-4"
      />
                </div>
                <div className=' h-10  col-span-3' >
                <ul className='hidden text-white font-medium text-base md:flex'>
      <NavLink to='/'><li className='p-4 hover:underline hover:text-red-200 '>HOME</li></NavLink>  
       <NavLink to='/task'><li className='p-4 hover:underline hover:text-red-200 ' >CURRENT_ISSUE</li>
       </NavLink> 
        
        <NavLink to='about'><li className='p-4 hover:underline hover:text-red-200 '>ABOUT</li></NavLink>
         <li className='p-4 hover:underline hover:text-red-200 '>CONTACT</li>
        <NavLink to='/add'><li className='p-4 hover:underline hover:text-red-200 '>ADD_ISSUE</li></NavLink>
      </ul>
                </div>
               <div className='bg-transparent h-10  col-span-4  text-end  gap-5 items-end text-white fixed top-8 right-0 font-semibold' >
                <NavLink to='/login'><button className='p-2 
                md:px-4 rounded-lg bg-gray-200  text-red-600 m-2 sm:m-4 lg:m-6 uppercase hover:bg-red-500 hover:text-white  transition duration-500 ease-in-out'>log in </button></NavLink>
                <NavLink to='/signup'><button className='p-2 md:px-4 bg-gray-200 rounded-lg m-2 md:m-4 lg:m-6 text-red-600 uppercase  hover:bg-red-500 hover:text-white transition duration-500 ease-in-out '>sign up</button></NavLink>
               </div>
               
               <div onClick={handleNav} className=' fixed right-0 top -0 block text-red-500 md:hidden'>
          {nav ? <AiOutlineClose size={20}/> : <AiOutlineMenu size={20} />}
      </div>
      
      <ul className={nav ? 'fixed left -0 top-0 w-[60%] h-full border-r border-r-gray-200 bg-white ease-in-out duration-500' : 'ease-in-out duration-500 fixed left-[-100%]'}>
        
        
        
          <li className='p-4 border-b border-gray-400'>HOME</li>
          <li className='p-4 border-b border-gray-400'>CURRENT_ISSUE</li>
          <li className='p-4 border-b border-gray-400'>ABOUT</li>
          <li className='p-4 border-b border-gray-400'>CONTACT</li>
          <li className='p-4'>ADD</li>
          
      </ul>
      

    </div> 
    <div className='text-white grid justify-center items-center font-serif text-xl lg:text-6xl mr-[10%] mt-[10%]'>
      <div>SOFTWARE </div> 
      <span className=' text-red-500 first-letter:text-white'>SOLUTIONS</span> 
    </div>  
  <main>
  <Outlet />
    </main>   
               
</div>

    
    
    
  );
};

export default Navbar;