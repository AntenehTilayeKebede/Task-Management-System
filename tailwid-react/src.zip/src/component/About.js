import React, { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { AiOutlineClose, AiOutlineMenu } from 'react-icons/ai';

const Navbar = () => {
  const [nav, setNav] = useState(false);

  const handleNav = () => {
    setNav(!nav);
  };

  return (
    <div className="bg-gray-900">
      <nav className="bg-gray-800 py-2 md:py-4">
        <div className="container mx-auto flex items-center justify-between">
          <a href="#" className="flex-shrink-0">
            <img src="images/white.png" alt="Logo" className="h-10 w-auto" />
          </a>
          <div className="hidden md:flex space-x-6">
            <NavLink
              to="/"
              activeClassName="text-red-200"
              className="text-white hover:text-red-200"
            >
              HOME
            </NavLink>
            <NavLink
              to="main"
              activeClassName="text-red-200"
              className="text-white hover:text-red-200"
            >
              CURRENT ISSUE
            </NavLink>
            <NavLink
              to="/about"
              activeClassName="text-red-200"
              className="text-white hover:text-red-200"
            >
              ABOUT
            </NavLink>
            <NavLink
              to="contactus"
              activeClassName="text-red-200"
              className="text-white hover:text-red-200"
            >
              CONTACT
            </NavLink>
            <NavLink
              to="/add"
              activeClassName="text-red-200"
              className="text-white hover:text-red-200"
            >
              ADD ISSUE
            </NavLink>
          </div>
          <div className="md:hidden">
            <button
              className="text-white p-2 focus:outline-none"
              onClick={handleNav}
            >
              {nav ? <AiOutlineClose size={20} /> : <AiOutlineMenu size={20} />}
            </button>
          </div>
        </div>
      </nav>

      <ul
        className={`${
          nav
            ? 'fixed top-14 left-0 w-[60%] h-full bg-gray-900 ease-in-out duration-500 text-white'
            : 'hidden md:hidden'
        }`}
      >
        <li className="p-4 border-b border-gray-400">HOME</li>
        <li className="p-4 border-b border-gray-400">CURRENT ISSUE</li>
        <li className="p-4 border-b border-gray-400">ABOUT</li>
        <li className="p-4 border-b border-gray-400">CONTACT</li>
        <li className="p-4">ADD</li>
      </ul>
      <div className="bg-gray-900">
      <div className="container mx-auto pt-16 pb-12">
        <div className="text-white text-center mb-12">
          <p className="text-lg md:text-xl font-semibold mb-4">
            At Issue Tracker X, we're all about innovative solutions for intricate challenges.
          </p>
          <p className="text-lg md:text-xl font-semibold">
            Driven by excellence, we've evolved into a dynamic company that offers intuitive issue tracking software.
          </p>
        </div>

        <h2 className="text-4xl md:text-5xl text-center text-white font-bold mb-8">
          OUR TEAM
        </h2>

        <div className="flex flex-col md:flex-row items-center justify-center mb-12">
          <img src="minale.jpg" className="w-48 h-48 md:w-64 md:h-64 rounded-full mb-4 md:mb-0" alt="Mr. Minale" />
          <div className="md:ml-8 text-white">
            <span className="text-lg md:text-xl font-semibold block mb-1">Company Owner</span>
            <span className="text-[#800000] text-lg md:text-xl">Mr. Minale</span>
          </div>
        </div>

        <h3 className="text-2xl md:text-3xl text-[#800000] text-center font-bold mb-8">
          Team Members
        </h3>

        <div className="flex flex-wrap justify-center">
          <img src="tibe.jpg" className="w-48 h-48 rounded-full m-4" alt="Tibebu" />
          <img src="mekid.jpg" className="w-48 h-48 rounded-full m-4" alt="Mekdes" />
          <img src="ante.jpg" className="w-48 h-48 rounded-full m-4" alt="Anteneh" />
          <img src="taye.jpg" className="w-48 h-48 rounded-full m-4" alt="Taye" />
        </div>
      </div>
    </div>
    </div>
  );
};

export default Navbar;
