import {FaFacebookSquare,
  FaInstagramSquare,
  FaTelegram, 
  FaGitSquare,

  FaWhatsappSquare,
  FaLinkedin

}from 'react-icons/fa'
const Footer = () => {
  return (
    <div id='footer'>
      <div className='  bg-black contain bg-cover mx-auto px-auto py-8 grid md:grid-cols-2 lg:grid-cols-3  gap-8 text-gray-300 pb-4px   justify-between' >
         <div className=' md:ml-20'>< FaFacebookSquare size={30} />
          FACEBOOK</div>
        <div>< FaInstagramSquare size={30}/>INSTAGRAM</div>
        <div>< FaTelegram size={30} /> TELEGRAM</div>
       <div className='md:ml-20'><FaGitSquare size={30}/>GIT HUB</div> 
       <div>< FaLinkedin size={30}/>LINKEDIN</div> 
       <div>< FaWhatsappSquare size={30}/>WHATSAPP</div>  
      </div>
    </div>
  )
}

export default Footer