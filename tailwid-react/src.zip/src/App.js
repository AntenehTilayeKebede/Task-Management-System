import Me from './component/Me';
import HomePage from './layout/Home';
import Login from './component/Login';
import Signup from './component/Signup';
import {Route, RouterProvider, createBrowserRouter, createRoutesFromElements } from 'react-router-dom';
import About from './component/About';
import Forma from './component/Forma';
import Current from './component/Current'

const router= createBrowserRouter(
  createRoutesFromElements(
    <Route >
     <Route path='/' element={<HomePage />}/>
     <Route path='/login' element={<Login />} />
      <Route path='/login/signup' element={<Signup />}/>
      <Route path='/task' element={<Current />}/>
     
     <Route path='/signup' element={<Signup />}/>
     <Route path='/add' element={<Forma />}/>

     <Route path='/about' element={<About />}/>

     
      
  <Route path='*' element={<Me />}/>
      </Route>

  )
)
function App() {
  return (
    <RouterProvider router={router} />
  );
}

export default App;
